#!/bin/bash

sudo apt-get install libmicrohttpd-dev libjsoncpp-dev libcurl4-openssl-dev cmake cppcheck valgrind gcovr
